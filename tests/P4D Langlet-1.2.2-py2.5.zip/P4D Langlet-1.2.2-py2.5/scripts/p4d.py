#!python

import sys
import EasyExtend
del sys.path[0]
EasyExtend.run("p4d")

