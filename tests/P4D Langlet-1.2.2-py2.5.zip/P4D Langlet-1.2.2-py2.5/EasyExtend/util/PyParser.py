# use this module if you want to import the parser of Pythons stdlib
import parser
PyParser = parser
ParserError = parser.ParserError
